
<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if($mysqli->connect_errno)
die('No se puede conectar: ' . $mysqli->connect_error);
$sql1 = 'SELECT inter.nombre_interes AS Subgeneros, COUNT(*) AS cantidad_interes FROM usuarios u JOIN intereses inter ON u.id_interes = inter.id_interes GROUP BY inter.nombre_interes';
$resultado = $mysqli->query($sql);

if(!$resultado)
    die('No se pudo realizar la consulta: ' . $mysqli->error);

$datos = "";

while($row1 = $resultado->fetch_assoc()) {
    $datos = $datos .  "['" . $row['Subgeneros'] . "'," . $row['cantidad_interes'] . "],";
}

$datos1 = rtrim($datos1,",");

echo('Consulta exitosa.');
$resultado->free();
$mysqli->close();
?>

<html>
  <head>
    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {'packages':['corechart']});

      // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', 'Slices');
        data.addRows([<?php echo $datos; ?>]);

        // Set chart options
        var options = {'title':'Subgeneros Seleccionados por usuarios',
                       'width':1200,
                       'height':1200};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
  </head>

  <body>
    <!--Div that will hold the pie chart-->
    <div id="chart_div"></div>
  </body>
</html>