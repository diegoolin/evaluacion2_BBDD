<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se han seleccionado subcategorías
    if (isset($_POST['subcategorias'])) {
        // Obtener las subcategorías seleccionadas
        $subcategorias_seleccionadas = $_POST['subcategorias'];
        
        // Hacer algo con las subcategorías seleccionadas, como almacenarlas en la base de datos o procesarlas de otra manera
        // Por ejemplo, puedes recorrer el array $subcategorias_seleccionadas y realizar alguna acción con cada subcategoría
    } else {
        // Si no se seleccionó ninguna subcategoría, puedes mostrar un mensaje de error o realizar otra acción
    }
}
?>
