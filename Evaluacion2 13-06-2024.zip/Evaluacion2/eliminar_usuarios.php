<?php
session_start();
include 'includes/db_connection.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'vendedor')) {
    header('Location: login.php');
    exit();
}

// Eliminar intereses y compras del usuario seleccionado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Eliminar ventas (solo para administradores)
    if (isset($_POST['delete_sales']) && $_SESSION['role'] === 'admin') {
        $vendedor_id = $_POST['vendedor_id'];
        $sql_delete_ventas = "DELETE FROM ventas WHERE id_vendedor = ?";
        $stmt_ventas = $conn->prepare($sql_delete_ventas);
        if (!$stmt_ventas) {
            die('Error en la preparación de la consulta de ventas: ' . $conn->error);
        }
        $stmt_ventas->bind_param('i', $vendedor_id);
        if (!$stmt_ventas->execute()) {
            die('Error al eliminar ventas: ' . $stmt_ventas->error);
        }
        header('Location: eliminar_usuarios.php');
        exit();
    }

    // Eliminar ventas (para vendedores)
    if (isset($_POST['delete_sales']) && $_SESSION['role'] === 'vendedor') {
        $vendedor_id = $_SESSION['user_id'];
        $sql_delete_ventas = "DELETE FROM ventas WHERE id_vendedor = ?";
        $stmt_ventas = $conn->prepare($sql_delete_ventas);
        if (!$stmt_ventas) {
            die('Error en la preparación de la consulta de ventas: ' . $conn->error);
        }
        $stmt_ventas->bind_param('i', $vendedor_id);
        if (!$stmt_ventas->execute()) {
            die('Error al eliminar ventas: ' . $stmt_ventas->error);
        }
        header('Location: eliminar_usuarios.php');
        exit();
    }

    // Eliminar intereses y compras
    $user_id = $_POST['user_id'];

    // Eliminar intereses
    $sql_delete_intereses = "DELETE FROM intereses WHERE id_usuario = ?";
    $stmt_intereses = $conn->prepare($sql_delete_intereses);
    if (!$stmt_intereses) {
        die('Error en la preparación de la consulta de intereses: ' . $conn->error);
    }
    $stmt_intereses->bind_param('i', $user_id);
    if (!$stmt_intereses->execute()) {
        die('Error al eliminar intereses: ' . $stmt_intereses->error);
    }

    // Eliminar compras
    $sql_delete_compras = "DELETE FROM ventas WHERE id_usuario = ?";
    $stmt_compras = $conn->prepare($sql_delete_compras);
    if (!$stmt_compras) {
        die('Error en la preparación de la consulta de compras: ' . $conn->error);
    }
    $stmt_compras->bind_param('i', $user_id);
    if (!$stmt_compras->execute()) {
        die('Error al eliminar compras: ' . $stmt_compras->error);
    }

    header('Location: eliminar_usuarios.php');
    exit();
}

// Obtener usuarios
$sql_usuarios = "SELECT id, nombre_usuario FROM usuarios";
$result_usuarios = $conn->query($sql_usuarios);

$usuarios = [];
if ($result_usuarios && $result_usuarios->num_rows > 0) {
    while ($row = $result_usuarios->fetch_assoc()) {
        $usuarios[] = $row;
    }
} else {
    die('Error en la consulta de usuarios: ' . $conn->error);
}

// Obtener vendedores (solo para administradores)
if ($_SESSION['role'] === 'admin') {
    $sql_vendedores = "SELECT id_vendedor, nombre_vendedor FROM vendedores";
    $result_vendedores = $conn->query($sql_vendedores);

    $vendedores = [];
    if ($result_vendedores && $result_vendedores->num_rows > 0) {
        while ($row = $result_vendedores->fetch_assoc()) {
            $vendedores[] = $row;
        }
    } else {
        die('Error en la consulta de vendedores: ' . $conn->error);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Intereses y Compras</title>
</head>
<body>
    <div class="admin-container">
        <h1>Eliminar Intereses y Compras</h1>
        <p>Selecciona un usuario o un vendedor para eliminar sus intereses y compras.</p>
        <form action="" method="post">
            <label for="user_id">Selecciona un usuario:</label>
            <select name="user_id" id="user_id" required>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id'] ?>"><?= $usuario['nombre_usuario'] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Eliminar Intereses y Compras</button>
        </form>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <form action="" method="post">
                <label for="vendedor_id">Selecciona un vendedor:</label>
                <select name="vendedor_id" id="vendedor_id" required>
                    <?php foreach ($vendedores as $vendedor): ?>
                        <option value="<?= $vendedor['id_vendedor'] ?>"><?= $vendedor['nombre_vendedor'] ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="delete_sales">Eliminar Ventas</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
