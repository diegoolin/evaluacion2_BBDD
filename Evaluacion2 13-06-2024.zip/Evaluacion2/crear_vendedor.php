<?php
session_start();
include 'includes/db_connection.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Obtener la fecha actual del sistema
$fecha_actual = date("Y-m-d");

// Insertar el nuevo vendedor en la base de datos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT); // Encriptar la contraseña

    // Insertar el nuevo vendedor en la base de datos
    $sql_insert = "INSERT INTO vendedores (nombre, email, contrasena, fecha_alta, fecha_creacion_cuenta) VALUES (?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param('sssss', $nombre, $email, $contrasena, $fecha_actual, $fecha_actual);
    $stmt_insert->execute();

    // Obtener el ID del nuevo vendedor
    $nuevo_id = $stmt_insert->insert_id;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Nuevo Vendedor</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .login-container {
            width: 300px;
            padding: 20px;
            background-color: #fff8dc;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h1 {
            margin-bottom: 20px;
            color: #8b7765;
        }
        .login-container input[type="email"],
        .login-container input[type="password"],
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .login-container input[type="email"]:focus,
        .login-container input[type="password"]:focus,
        .login-container input[type="submit"]:hover {
            border-color: #d2b48c;
            outline: none;
        }
        .login-container input[type="submit"] {
            background-color: #8b7765;
            color: white;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #654321;
        }
        .login-container .error {
            color: #dc3545;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Crear Nuevo Vendedor</h1>
        <form action="crear_vendedor.php" method="post">
            <!-- Campos del formulario -->
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" required><br>

            <!-- Mostrar el ID asociado después de guardar al usuario -->
            <?php if (isset($nuevo_id)): ?>
                <p>Nuevo ID asociado: <?php echo $nuevo_id; ?></p>
            <?php endif; ?>

            <button type="submit">Guardar Vendedor</button>
        </form>
    </div>
</body>
</html>
