<?php
session_start();
include 'includes/db_connection.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Manejar la actualización y eliminación de subcategorías
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $sql = "UPDATE subgenero SET nombre_subgenero = ? WHERE id_subgenero = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('si', $nombre, $id);
        $stmt->execute();
    } elseif (isset($_POST['delete'])) {
        $id = $_POST['id'];
        $sql = "DELETE FROM subgenero WHERE id_subgenero = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
    }
}

// Obtener todas las subcategorías
$sql = "SELECT id_subgenero, nombre_subgenero FROM subgenero";
$result = $conn->query($sql);
$subcategorias = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administrar Categorías y Subcategorías</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .login-container {
            width: 300px;
            padding: 20px;
            background-color: #fff8dc;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h1 {
            margin-bottom: 20px;
            color: #8b7765;
        }
        .login-container input[type="email"],
        .login-container input[type="password"],
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .login-container input[type="email"]:focus,
        .login-container input[type="password"]:focus,
        .login-container input[type="submit"]:hover {
            border-color: #d2b48c;
            outline: none;
        }
        .login-container input[type="submit"] {
            background-color: #8b7765;
            color: white;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #654321;
        }
        .login-container .error {
            color: #dc3545;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Administrar Categorías y Subcategorías</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre Subcategoría</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subcategorias as $subcategoria): ?>
                    <tr>
                        <form method="post">
                            <td><?= $subcategoria['id_subgenero'] ?></td>
                            <td><input type="text" name="nombre" value="<?= $subcategoria['nombre_subgenero'] ?>"></td>
                            <td>
                                <input type="hidden" name="id" value="<?= $subcategoria['id_subgenero'] ?>">
                                <button type="submit" name="update">Actualizar</button>
                                <button type="submit" name="delete">Eliminar</button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
