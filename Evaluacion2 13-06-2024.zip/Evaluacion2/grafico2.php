<?php
// Configuración de la conexión a la base de datos
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';

// Crear una nueva instancia de conexión mysqli
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Verificar la conexión
if ($mysqli->connect_errno) {
    die('No se puede conectar: ' . $mysqli->connect_error);
}

// Consulta para los montos totales de ventas por subgénero
$sql2 = 'SELECT sub.nombre_subgenero AS Subgenero, SUM(lib.precio * venta.cantidad_libros) AS MontoTotal 
         FROM venta 
         JOIN libros lib ON venta.ISBN = lib.ISBN 
         JOIN subgenero sub ON lib.id_subgenero = sub.id_subgenero 
         GROUP BY sub.nombre_subgenero';

// Ejecutar la consulta
$resultado2 = $mysqli->query($sql2);

// Verificar si la consulta fue exitosa
if (!$resultado2) {
    die('No se pudo realizar la consulta: ' . $mysqli->error);
}

// Procesar los resultados
$datos2 = "";

while ($row = $resultado2->fetch_assoc()) {
    $datos2 .= "['" . $row['Subgenero'] . "'," . $row['MontoTotal'] . "],";
}

$datos2 = rtrim($datos2, ",");

// Liberar el resultado
$resultado2->free();

// Cerrar la conexión
$mysqli->close();

// Retornar o imprimir los datos según sea necesario
echo $datos2;
?>

