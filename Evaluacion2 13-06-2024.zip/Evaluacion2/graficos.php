<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'libreria';
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if($mysqli->connect_errno)
die('No se puede conectar: ' . $mysqli->connect_error);
$sql1 = 'SELECT inter.nombre_interes AS Subgeneros, COUNT(*) AS cantidad_interes FROM usuarios u JOIN intereses inter ON u.id_interes = inter.id_interes GROUP BY inter.nombre_interes';
$resultado = $mysqli->query($sql1);

if(!$resultado)
    die('No se pudo realizar la consulta: ' . $mysqli->error);

$datos1 = "";

while($row = $resultado->fetch_assoc()) {
    $datos1 = $datos1 .  "['" . $row['Subgeneros'] . "'," . $row['cantidad_interes'] . "],";
}

$datos1 = rtrim($datos1,",");

echo('Consulta exitosa.');
$resultado->free();
$mysqli->close();
?>

<html>
  <head>
    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {'packages':['corechart']});

      // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

        // Create the data table for Pie Chart.
        var dataPie = new google.visualization.DataTable();
        dataPie.addColumn('string', 'Topping');
        dataPie.addColumn('number', 'Slices');
        dataPie.addRows([<?php echo $datos1; ?>]);

        // Set chart options for Pie Chart.
        var optionsPie = {'title':'Subgeneros Seleccionados por usuarios',
                       'width':1200,
                       'height':1200};

        // Instantiate and draw the Pie chart.
        var chartPie = new google.visualization.PieChart(document.getElementById('chart_div_pie'));
        chartPie.draw(dataPie, optionsPie);

        // Create the data table for Line Chart.
        var dataLine = new google.visualization.DataTable();
        dataLine.addColumn('string', 'Subgeneros');
        dataLine.addColumn('number', 'Cantidad de Intereses');
        dataLine.addRows([<?php echo $datos1; ?>]);

        // Set chart options for Line Chart.
        var optionsLine = {'title':'Subgeneros Seleccionados por usuarios',
                       'width':600,
                       'height':400};

        // Instantiate and draw the Line chart.
        var chartLine = new google.visualization.LineChart(document.getElementById('chart_div_line'));
        chartLine.draw(dataLine, optionsLine);
      }
    </script>
  </head>

  <body>
    <!--Divs that will hold the charts-->
    <div id="chart_div_pie"></div>
    <div id="chart_div_line"></div>
  </body>
</html>
