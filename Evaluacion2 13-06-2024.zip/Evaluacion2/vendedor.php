<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Librería - Datos del Vendedor</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 95%;
            max-width: 800px;
            padding: 20px;
            background-color: #fff8dc;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #8b7765;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        table th {
            background-color: #d2b48c;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #fff8dc;
        }
        table tr:hover {
            background-color: #f5f5dc;
        }
        .back-link {
            margin-top: 20px;
        }
        .back-link a {
            padding: 10px 20px;
            background-color: #8b7765;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .back-link a:hover {
            background-color: #654321;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "libreria";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        if (isset($_GET['libro_id'])) {
            $libro_id = $_GET['libro_id'];

            $sql = "SELECT * FROM vendedores WHERE id_vendedor IN (SELECT id_vendedor FROM libros WHERE ISBN = '$libro_id')";
            
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<h1>Datos del vendedor</h1>";
                echo "<table>";
                echo "<tr><th>ID Vendedor</th><th>Nombre</th><th>Email</th><th>Telefono</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id_vendedor"] . "</td>";
                    echo "<td>" . $row["nombre_vendedor"] . "</td>";
                    echo "<td>" . $row["email_vendedor"] . "</td>";
                    echo "<td>" . $row["telefono_vendedor"] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No se encontraron vendedores asignados para este libro.</p>";
            }
        } else {
            echo "<p>ID de libro no proporcionado.</p>";
        }

        $conn->close();
        ?>
        <div class="back-link">
            <a href="javascript:history.go(-1)">Volver</a>
        </div>
    </div>
</body>
</html>

