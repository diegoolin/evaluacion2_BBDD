<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Librería - Datos del Vendedor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 95%;
            padding: 45px;
            background-color: #fff;
            border-radius: 100px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            background: #f4f4f4;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .form-group {
            margin: 10px;
            flex: 1;
            min-width: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form select,
        form input[type="text"],
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background-color: #f4f4f4;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .button-container {
            display: flex;
            justify-content: center;
        }
        .button {
            padding: 5px 10px;
            text-decoration: none;
            background-color: #5bc0de;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .button:hover {
            background-color: #31b0d5;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenido a la librería</h1>
        <!-- Filtro de búsqueda -->
        <form action="" method="GET">
            <input type="text" name="busqueda" placeholder="Buscar por título...">
            <input type="submit" value="Buscar">
        </form>
        
        <!-- Formulario de filtro por género -->
        <form action="" method="GET">
            <div class="form-group">
                <label for="genero">Filtrar por Género:</label>
                <select name="genero" id="genero">
                    <option value="">Todos los Géneros</option>
                    <?php
                    // Conexión a la base de datos
                    include 'includes/db_connection.php';

                    // Consulta para obtener los géneros disponibles
                    $sql_generos = "SELECT * FROM genero";
                    $result_generos = $conn->query($sql_generos);

                    if ($result_generos->num_rows > 0) {
                        while($row_genero = $result_generos->fetch_assoc()) {
                            // Verificar si este género está seleccionado actualmente
                            $selected = '';
                            if(isset($_GET['genero']) && $_GET['genero'] == $row_genero["id_genero"]) {
                                $selected = 'selected';
                            }
                            echo "<option value='" . $row_genero["id_genero"] . "' $selected>" . $row_genero["nombre_genero"] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="subgenero">Filtrar por Subgénero:</label>
                <select name="subgenero" id="subgenero">
                    <option value="">Todos los Subgéneros</option>
                    <?php
                    // Consulta para obtener los subgéneros disponibles
                    $sql_subgeneros = "SELECT * FROM subgenero";
                    $result_subgeneros = $conn->query($sql_subgeneros);

                    if ($result_subgeneros->num_rows > 0) {
                        while($row_subgenero = $result_subgeneros->fetch_assoc()) {
                            // Verificar si este subgénero está seleccionado actualmente
                            $selected = '';
                            if(isset($_GET['subgenero']) && $_GET['subgenero'] == $row_subgenero["id_subgenero"]) {
                                $selected = 'selected';
                            }
                            echo "<option value='" . $row_subgenero["id_subgenero"] . "' $selected>" . $row_subgenero["nombre_subgenero"] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>

           
            <input type="submit" value="Filtrar">
        </form>

        <!-- Mostrar los libros filtrados -->
        <div id="libros">
            <?php
            // Construir la consulta SQL base
            $sql = "SELECT l.ISBN, l.Titulo, l.descripcion, l.formato, l.autor, l.idioma, l.disponibilidad, l.precio, l.fecha_creacion, l.id_subgenero, s.nombre_subgenero, g.id_genero, g.nombre_genero, l.id_vendedor, v.nombre_vendedor 
                    FROM libros l
                    LEFT JOIN subgenero s ON l.id_subgenero = s.id_subgenero
                    LEFT JOIN genero g ON s.id_genero = g.id_genero
                    LEFT JOIN vendedores v ON l.id_vendedor = v.id_vendedor";

            // Verificar si se ha seleccionado un género para filtrar
            if(isset($_GET['genero']) && !empty($_GET['genero'])) {
                $genero_id = $_GET['genero'];
                $sql .= " WHERE g.id_genero = $genero_id";
            }

            // Verificar si se ha seleccionado un subgénero para filtrar
            if(isset($_GET['subgenero']) && !empty($_GET['subgenero'])) {
                $subgenero_id = $_GET['subgenero'];
                if (strpos($sql, 'WHERE') !== false) {
                    $sql .= " AND l.id_subgenero = $subgenero_id";
                } else {
                    $sql .= " WHERE l.id_subgenero = $subgenero_id";
                }
            }

          

            // Ejecutar la consulta SQL
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                echo "<table border='1'>
                        <tr>
                            <th>ISBN</th>
                            <th>Título</th>
                            <th>Descripción</th>
                            <th>Formato</th>
                            <th>Autor</th>
                            <th>Idioma</th>
                            <th>Disponibilidad</th>
                            <th>Precio</th>
                            <th>Fecha de Creación</th>
                            <th>Subgénero</th>
                            <th>Género</th>
                            <th>Ver Datos del Vendedor</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["ISBN"] . "</td>";
                    echo "<td>" . $row["Titulo"] . "</td>";
                    echo "<td>" . $row["descripcion"] . "</td>";
                    echo "<td>" . $row["formato"] . "</td>";
                    echo "<td>" . $row["autor"] . "</td>";
                    echo "<td>" . $row["idioma"] . "</td>";
                    echo "<td>" . $row["disponibilidad"] . "</td>";
                    echo "<td>" . $row["precio"] . "</td>";
                    echo "<td>" . $row["fecha_creacion"] . "</td>";
                    echo "<td>" . $row["nombre_subgenero"] . "</td>";
                    echo "<td>" . $row["nombre_genero"] . "</td>";
                    echo "<td><a class='button' href='vendedor.php?libro_id=" . $row["ISBN"] . "'>Ver Datos del Vendedor</a></td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No se encontraron libros</p>";
            }
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
