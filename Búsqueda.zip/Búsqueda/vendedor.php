<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Librería - Datos del Vendedor</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "libreria";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        if (isset($_GET['libro_id'])) {
            $libro_id = $_GET['libro_id'];

            $sql = "SELECT * FROM vendedores WHERE id_vendedor IN (SELECT id_vendedor FROM libros WHERE ISBN = '$libro_id')";
            
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<h1>Datos del vendedor</h1>";
                echo "<table>";
                echo "<tr><th>ID Vendedor</th><th>Nombre</th><th>Email</th><th>Telefono</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id_vendedor"] . "</td>";
                    echo "<td>" . $row["nombre_vendedor"] . "</td>";
                    echo "<td>" . $row["email_vendedor"] . "</td>";
                    echo "<td>" . $row["telefono_vendedor"] . "</td>";

                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No se encontraron vendedores asignados para este libro.</p>";
            }
        } else {
            echo "<p>ID de libro no proporcionado.</p>";
        }

        $conn->close();
        ?>
        <div class="back-link">
            <a href="javascript:history.go(-1)">Volver</a>
        </div>
    </div>
</body>
</html>
