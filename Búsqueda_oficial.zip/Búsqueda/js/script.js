document.addEventListener("DOMContentLoaded", function() {
  const form = document.querySelector("form");
  const resultadosDiv = document.getElementById("resultados");

  form.addEventListener("submit", function(event) {
      event.preventDefault();

      const formData = new FormData(form);

      const xhr = new XMLHttpRequest();
      xhr.open("GET", "search.php?" + new URLSearchParams(formData).toString(), true);

      xhr.onload = function() {
          if (xhr.status === 200) {

              resultadosDiv.innerHTML = xhr.responseText;
          } else {
              console.error("Error al realizar la solicitud: " + xhr.status);
          }
      };

      xhr.onerror = function() {
          console.error("Error de red al realizar la solicitud");
      };

      xhr.send();
  });
});
