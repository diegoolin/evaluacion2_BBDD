<?php
session_start();
include 'includes/db_connection.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Obtener el correo electrónico del administrador desde la base de datos
$admin_id = $_SESSION['user_id'];
$sql = "SELECT nombre_admin FROM administradores WHERE id_admin = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$email = $admin['nombre_admin'] ?? '';

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Página de Administrador</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .admin-container {
            text-align: center;
        }
        .admin-container h1 {
            color: #8b7765;
            margin-bottom: 20px;
        }
        .admin-container p {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .admin-container ul {
            list-style-type: none;
            padding: 0;
        }
        .admin-container li {
            margin-bottom: 15px; /* Aumentar el espacio entre elementos de la lista */
        }
        .admin-container a {
            text-decoration: none;
            color: #333;
            padding: 10px 20px; /* Aumentar el espacio interno del enlace */
            background-color: #8b7765;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .admin-container a:hover {
            background-color: #654321;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Bienvenido, Administrador</h1>
        <?php if (!empty($email)): ?>
            <p>Nombre del Administrador: <?= $email ?></p>
        <?php endif; ?>
        <h2>Menú de opciones:</h2>
        <ul>
            <li><a href="categorias.php">Administrar Categorías y Subcategorías</a></li>
            <li><br></li> <!-- Agregando un espacio entre las opciones -->
            <li><a href="crear_vendedor.php">Crear Nuevo Vendedor</a></li>
        </ul>
    </div>
</body>
</html>




