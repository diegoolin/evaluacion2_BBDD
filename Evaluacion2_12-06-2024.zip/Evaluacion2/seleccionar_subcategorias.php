<?php

include 'includes/db_connection.php';


// Coloca este código PHP en la parte superior del archivo seleccionar_subcategorias.php

// Consulta SQL para obtener las subcategorías de la base de datos
$sql = "SELECT id_subgenero, nombre_subgenero FROM subgenero";
$result = $conn->query($sql);

$subcategorias = array(); // Array para almacenar las subcategorías recuperadas

if ($result->num_rows > 0) {
    // Recorre los resultados y agrega cada subcategoría al array
    while ($row = $result->fetch_assoc()) {
        $subcategorias[] = $row;
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Seleccionar Subcategorías</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .login-container {
            width: 300px;
            padding: 20px;
            background-color: #fff8dc;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h1 {
            margin-bottom: 20px;
            color: #8b7765;
        }
        .login-container input[type="email"],
        .login-container input[type="password"],
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .login-container input[type="email"]:focus,
        .login-container input[type="password"]:focus,
        .login-container input[type="submit"]:hover {
            border-color: #d2b48c;
            outline: none;
        }
        .login-container input[type="submit"] {
            background-color: #8b7765;
            color: white;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #654321;
        }
        .login-container .error {
            color: #dc3545;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Seleccionar Subcategorías</h1>
        <?php if (!empty($email)): ?>
            <p>Nombre del Administrador: <?= $email ?></p>
        <?php endif; ?>
        <h2>Menú de opciones:</h2>
        <ul>
            <li><a href="categorias.php">Administrar Categorías y Subcategorías</a></li>
            <li><br></li> <!-- Agregando un espacio entre las opciones -->
            <li><a href="seleccionar_subcategorias.php">Crear Nuevo Vendedor</a></li>
            <li><br></li> <!-- Agregando un espacio entre las opciones -->
            <li><a href="crear_comprador.php">Crear Nuevo Comprador</a></li> <!-- Nuevo botón para agregar comprador -->
        </ul>

        <form action="procesar_seleccion_subcategorias.php" method="post">
    <label>Selecciona las subcategorías de interés:</label><br>
    <?php foreach ($subcategorias as $subcategoria): ?>
        <input type="checkbox" name="subcategorias[]" value="<?php echo $subcategoria['id_subgenero']; ?>">
        <?php echo $subcategoria['nombre_subgenero']; ?><br>
    <?php endforeach; ?>
    <br>
    <button type="submit">Guardar Selección</button>
</form>

    </div>
</body>
</html>
