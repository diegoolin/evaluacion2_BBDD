<?php
session_start();

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Procesar los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];

    // Verificar y actualizar el nombre de usuario
    if (!empty($_POST['new_name'])) {
        $new_name = $_POST['new_name'];
        $sql_update_name = "UPDATE usuarios SET nombre_usuario = ? WHERE id = ?";
        $stmt_update_name = $conn->prepare($sql_update_name);
        $stmt_update_name->bind_param("si", $new_name, $user_id);
        $stmt_update_name->execute();
        $stmt_update_name->close();
    }

    // Verificar y actualizar el correo electrónico
    if (!empty($_POST['new_email'])) {
        $new_email = $_POST['new_email'];
        $sql_update_email = "UPDATE usuarios SET email_usu = ? WHERE id = ?";
        $stmt_update_email = $conn->prepare($sql_update_email);
        $stmt_update_email->bind_param("si", $new_email, $user_id);
        $stmt_update_email->execute();
        $stmt_update_email->close();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_id = $_SESSION['user_id'];
    
        // Verificar y actualizar la contraseña
        if (!empty($_POST['new_password'])) {
            $new_password = $_POST['new_password'];
            // No hashear la contraseña, almacenarla en texto plano
            $sql_update_password = "UPDATE usuarios SET contraseña_usu = '$new_password' WHERE id = $user_id";
            $conn->query($sql_update_password);
        }
    }
    


    // Verificar y actualizar el interés
if (!empty($_POST['new_interest'])) {
    $new_interest = $_POST['new_interest'];

    // Obtener el nombre del interés correspondiente al nuevo ID de subgénero
    $sql_select_interest_name = "SELECT nombre_interes FROM intereses WHERE id_subgenero = ?";
    $stmt_select_interest_name = $conn->prepare($sql_select_interest_name);
    $stmt_select_interest_name->bind_param("i", $new_interest);
    $stmt_select_interest_name->execute();
    $stmt_select_interest_name->store_result();

    // Verificar si se encontró el nombre del interés
    if ($stmt_select_interest_name->num_rows > 0) {
        $stmt_select_interest_name->bind_result($new_interest_name);
        $stmt_select_interest_name->fetch();
        $stmt_select_interest_name->close();

        // Actualizar el ID del subgénero en la tabla de intereses
        $sql_update_interest = "UPDATE intereses SET id_subgenero = ?, nombre_interes = ? WHERE id_usuario = ?";
        $stmt_update_interest = $conn->prepare($sql_update_interest);
        $stmt_update_interest->bind_param("isi", $new_interest, $new_interest_name, $user_id);

        if ($stmt_update_interest->execute()) {
            // Actualización exitosa
            $stmt_update_interest->close();
            // Redireccionar a una página de éxito o mostrar un mensaje de éxito
        } else {
            // Error al actualizar
            // Manejar el error apropiadamente, por ejemplo, mostrar un mensaje de error
            echo "Error al actualizar el interés: " . $conn->error;
        }
    } else {
        // No se encontró el nombre del interés correspondiente al ID del subgénero
        echo "No se encontró el nombre del interés correspondiente al ID del subgénero.";
    }
}


    // Mostrar mensaje de éxito
    echo "<p>Los cambios se han guardado correctamente.</p>";
}

// Consulta para obtener los datos actuales del usuario
$user_id = $_SESSION['user_id'];
$sql_user_data = "SELECT nombre_usuario, email_usu FROM usuarios WHERE id = ?";
$stmt_user_data = $conn->prepare($sql_user_data);
$stmt_user_data->bind_param("i", $user_id);
$stmt_user_data->execute();
$result_user_data = $stmt_user_data->get_result();
$user_data = $result_user_data->fetch_assoc();
$stmt_user_data->close();

// Consulta para obtener el interés actual del usuario
$sql_current_interest = "SELECT id_subgenero FROM intereses WHERE id_usuario = ?";
$stmt_current_interest = $conn->prepare($sql_current_interest);
$stmt_current_interest->bind_param("i", $user_id);
$stmt_current_interest->execute();
$result_current_interest = $stmt_current_interest->get_result();
$current_interest = $result_current_interest->fetch_assoc()['id_subgenero'];
$stmt_current_interest->close();

// Consulta para obtener todos los subgéneros disponibles
$sql_subgenres = "SELECT DISTINCT id_subgenero, nombre_interes FROM intereses";
$result_subgenres = $conn->query($sql_subgenres);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Datos de la Cuenta</title>
    <style>
        body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5dc;
    margin: 0;
    padding: 0;
    color: #333;
    }
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        background-color: #d2b48c;
        color: white;
    }
    header h1 {
        margin: 0;
    }
    .login-button {
        padding: 10px 20px;
        background-color: #8b7765;
        color: white;
        border: none;
        border-radius: 5px;
        text-decoration: none;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .login-button:hover {
        background-color: #654321;
    }
    .container {
        width: 95%;
        max-width: 2000px;
        padding: 45px;
        background-color: #fff8dc;
        border-radius: 20px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        margin: 60px auto;
        text-align: center;
    }
    h1 {
        color: #8b7765;
        margin-bottom: 20px;
    }
    form {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        background: #fff8dc;
        padding: 20px;
        border-radius: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }
    .form-group {
        margin: 10px;
        flex: 1;
        min-width: 150px;
    }
    form label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    form select,
    form input[type="text"],
    form input[type="submit"],
    form button {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ced4da;
        border-radius: 5px;
        box-sizing: border-box;
        font-size: 14px;
        transition: border-color 0.3s;
    }
    form input[type="text"]:focus,
    form select:focus,
    form input[type="submit"]:hover,
    form button:hover {
        border-color: #d2b48c;
        outline: none;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    table th, table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #dee2e6;
    }
    table th {
        background-color: #d2b48c;
        color: white;
    }
    table tr:nth-child(even) {
        background-color: #fff8dc;
    }
    table tr:hover {
        background-color: #f5f5dc;
    }
    .button-container {
        display: flex;
        justify-content: center;
    }
    .button {
        padding: 10px 20px;
        text-decoration: none;
        background-color: #8b7765;
        color: white;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        border: none;
        cursor: pointer;
    }
    .button:hover {
        background-color: #654321;
    }
    .no-books {
        color: #dc3545;
        font-weight: bold;
        margin-top: 20px;
    }
    .description-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: #8b7765;
        color: white;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        border: none;
        cursor: pointer;
    }
    .description-button:hover {
        background-color: #654321;
    }
    .description {
        display: none;
        text-align: left;
        padding: 10px;
        margin-top: 10px;
        border: 1px solid #ddd;
        background-color: #f9f9f9;
    }

    </style>
</head>
<body>
    <h1>Modificar Datos de la Cuenta</h1>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="new_name">Nuevo Nombre de Usuario:</label>
            <input type="text" id="new_name" name="new_name" value="<?php echo htmlspecialchars($user_data['nombre_usuario']); ?>">
        </div>
        <div class="form-group">
            <label for="new_email">Nuevo Correo Electrónico:</label>
            <input type="email" id="new_email" name="new_email" value="<?php echo htmlspecialchars($user_data['email_usu']); ?>">
        </div>
        <div class="form-group">
            <label for="new_password">Nueva Contraseña:</label>
            <input type="password" id="new_password" name="new_password">
        </div>
        <div class="form-group">
            <label for="new_interest">Nuevo Interés:</label>
            <select id="new_interest" name="new_interest">
                <?php
                // Iterar sobre los subgéneros disponibles y mostrarlos en el menú desplegable
                while ($row =$result_subgenres->fetch_assoc()) {
                    $selected = ($row['id_subgenero'] == $current_interest) ? "selected" : "";
                    echo "<option value='" . htmlspecialchars($row['id_subgenero']) . "' $selected>" . htmlspecialchars($row['nombre_interes']) . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <input type="submit" value="Guardar Cambios">
            <!-- Botón para volver al menú anterior -->
            <a href="usuarios.php"><button type="button">Volver al Menú Anterior</button></a>
        </div>
    </form>
</body>
</html>




