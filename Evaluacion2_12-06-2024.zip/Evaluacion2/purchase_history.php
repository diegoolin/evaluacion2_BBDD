<?php
session_start();
include 'includes/db_connection.php'; 

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial de Compras</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            color: #333;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #d2b48c;
            color: white;
        }
        header h1 {
            margin: 0;
        }
        .header-buttons {
            display: flex;
            gap: 10px;
        }
        .button {
            padding: 10px 20px;
            background-color: #8b7765;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #654321;
        }
        .container {
            width: 95%;
            max-width: 1200px;
            padding: 45px;
            background-color: #fff8dc;
            border-radius: 20px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin: 60px auto;
            text-align: center;
        }
        h1 {
            color: #8b7765;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            background: #fff8dc;
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .form-group {
            margin: 10px;
            flex: 1;
            min-width: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form select,
        form input[type="date"],
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        form input[type="date"]:focus,
        form select:focus,
        form input[type="submit"]:hover {
            border-color: #d2b48c;
            outline: none;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        table th {
            background-color: #d2b48c;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #fff8dc;
        }
        table tr:hover {
            background-color: #f5f5dc;
        }
        .no-books {
            color: #dc3545;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Historial de Compras</h1>
        <div class="header-buttons">
            <a href="usuarios.php" class="button">Volver a Usuarios</a>
        </div>
    </header>
    <div class="container">
        <h1>Buscar en el Historial de Compras</h1>
        <!-- Formulario de búsqueda -->
        <form action="" method="GET">
            <div class="form-group">
                <label for="fecha_inicio">Fecha de Inicio:</label>
                <input type="date" name="fecha_inicio" id="fecha_inicio" value="<?php echo isset($_GET['fecha_inicio']) ? $_GET['fecha_inicio'] : ''; ?>">
            </div>
            <div class="form-group">
                <label for="fecha_fin">Fecha de Fin:</label>
                <input type="date" name="fecha_fin" id="fecha_fin" value="<?php echo isset($_GET['fecha_fin']) ? $_GET['fecha_fin'] : ''; ?>">
            </div>
            <div class="form-group">
                <label for="categoria">Categoría:</label>
                <select name="categoria" id="categoria">
                    <option value="">Todas las Categorías</option>
                    <?php
                    // Consulta para obtener las categorías disponibles
                    $sql_categorias = "SELECT * FROM categoria";
                    $result_categorias = $conn->query($sql_categorias);

                    if ($result_categorias->num_rows > 0) {
                        while($row_categoria = $result_categorias->fetch_assoc()) {
                            $selected = '';
                            if (isset($_GET['categoria']) && $_GET['categoria'] == $row_categoria["id_categoria"]) {
                                $selected = 'selected';
                            }
                            echo "<option value='" . $row_categoria["id_categoria"] . "' $selected>" . $row_categoria["nombre_categoria"] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="subcategoria">Subcategoría:</label>
                <select name="subcategoria" id="subcategoria">
                    <option value="">Todas las Subcategorías</option>
                    <?php
                    // Consulta para obtener las subcategorías disponibles
                    $sql_subcategorias = "SELECT * FROM subcategoria";
                    $result_subcategorias = $conn->query($sql_subcategorias);

                    if ($result_subcategorias->num_rows > 0) {
                        while($row_subcategoria = $result_subcategorias->fetch_assoc()) {
                            $selected = '';
                            if (isset($_GET['subcategoria']) && $_GET['subcategoria'] == $row_subcategoria["id_subcategoria"]) {
                                $selected = 'selected';
                            }
                            echo "<option value='" . $row_subcategoria["id_subcategoria"] . "' $selected>" . $row_subcategoria["nombre_subcategoria"] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" value="Filtrar">
            </div>
        </form>

        <!-- Mostrar las compras filtradas -->
        <div id="compras">
            <?php
            // Construir la consulta SQL base
            $sql = "SELECT c.id_compra, c.fecha_compra, c.total, cat.nombre_categoria, subcat.nombre_subcategoria 
                    FROM compras c
                    LEFT JOIN subcategoria subcat ON c.id_subcategoria = subcat.id_subcategoria
                    LEFT JOIN categoria cat ON subcat.id_categoria = cat.id_categoria
                    WHERE c.id_usuario = {$_SESSION['user_id']}";

            $conditions = [];

            // Verificar si se ha establecido un intervalo de tiempo
            if (isset($_GET['fecha_inicio']) && !empty($_GET['fecha_inicio'])) {
                $fecha_inicio = $_GET['fecha_inicio'];
                $conditions[] = "c.fecha_compra >= '$fecha_inicio'";
            }
            if (isset($_GET['fecha_fin']) && !empty($_GET['fecha_fin'])) {
                $fecha_fin = $_GET['fecha_fin'];
                $conditions[] = "c.fecha_compra <= '$fecha_fin'";
            }

            // Verificar si se ha seleccionado una categoría para filtrar
            if (isset($_GET['categoria']) && !empty($_GET['categoria'])) {
                $categoria_id = $_GET['categoria'];
                $conditions[] = "cat.id_categoria = $categoria_id";
            }

            // Verificar si se ha seleccionado una subcategoría para filtrar
            if (isset($_GET['subcategoria']) && !empty($_GET['subcategoria'])) {
                $subcategoria_id = $_GET['subcategoria'];
                $conditions[] = "subcat.id_subcategoria = $subcategoria_id";
            }

            // Combinar las condiciones con 'AND' y agregarlas a la consulta
            if (count($conditions) > 0) {
                $sql .= ' AND ' . implode(' AND ', $conditions);
            }

            // Ejecutar la consulta SQL
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table border='1'>
                        <tr>
                            <th>ID Compra</th>
                            <th>Fecha de Compra</th>
                            <th>Total</th>
                            <th>Categoría</th>
                            <th>Subcategoría</th>
                        </tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id_compra"] . "</td>";
                    echo "<td>" . $row["fecha_compra"] . "</td>";
                    echo "<td>" . $row["total"] . "</td>";
                    echo "<td>" . $row["nombre_categoria"] . "</td>";
                    echo "<td>" . $row["nombre_subcategoria"] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='no-books'>No se encontraron compras</p>";
            }
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>

