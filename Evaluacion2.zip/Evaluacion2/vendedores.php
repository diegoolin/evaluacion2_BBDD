<?php
session_start();

// Verificar si el usuario ha iniciado sesión como vendedor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'vendedor') {
    header('Location: login.php');
    exit();
}

// Obtener el nombre del vendedor desde la base de datos o cualquier otro método
$nombre_vendedor = "Vendedor";

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido Vendedor</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .welcome-container {
            text-align: center;
        }
        .welcome-message {
            font-size: 24px;
            color: #8b7765;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <h1>Bienvenido, <?php echo $nombre_vendedor; ?></h1>
        <p class="welcome-message">¡Gracias por iniciar sesión como vendedor!</p>
    </div>
</body>
</html>
